package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.TableLayout;
import android.widget.Toast;

import com.example.myapplication.databinding.ActivityAjudaBinding;
import com.example.myapplication.databinding.ActivityMainBinding;
import com.example.myapplication.databinding.FragmentPostosFragmentsBinding;
import com.example.myapplication.fragments.ContatoFragments;
import com.example.myapplication.fragments.PostosFragments;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

public class Ajuda extends AppCompatActivity{

    private TabLayout tabLayout;
    private ViewPager2 viewPager2;
    private FragmentStateAdapter fragmentStateAdapter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_ajuda);
        tabLayout = findViewById(R.id.tabs);
        viewPager2 = findViewById(R.id.viewpage);
        getSupportActionBar().hide();


        viewPager2.setAdapter(fragmentStateAdapter = new FragmentStateAdapter(getSupportFragmentManager(),getLifecycle()) {
            @NonNull
            @Override
            public Fragment createFragment(int position) {
                switch (position){
                    case 0:
                        ContatoFragments contatoFragments = new ContatoFragments();
                        return contatoFragments;
                    case 1:
                        PostosFragments postosFragments = new PostosFragments();
                        return postosFragments;
                    default:
                        return null;
                }
            }

            @Override
            public int getItemCount() {
                return tabLayout.getTabCount();
            }
        });
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager2.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
    }
}