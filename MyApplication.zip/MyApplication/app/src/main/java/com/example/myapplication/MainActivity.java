package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    MediaPlayer mediaPlayer;
    // criando os representantes
    private EditText editAlcool, editGasolina;
    private TextView textDescricao, textResultado;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mediaPlayer = MediaPlayer.create(this, R.raw.water);
        // atrelando os representantes aos componetes
        editAlcool = findViewById(R.id.editEtanol);
        editGasolina = findViewById(R.id.editGasolina);


        textResultado = findViewById(R.id.textResultado);
        textDescricao = findViewById(R.id.textDescricao);

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu){

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @SuppressLint({"SetTextI18n", "DefaultLocale"})
    public void calcular (View viem){
        mediaPlayer.start();
        double precoGasolina = Double.parseDouble(editGasolina.getText().toString());
        double precoAlcool   = Double.parseDouble(editAlcool.getText().toString());
        double resultado     = precoAlcool/precoGasolina;

        /* se o preçoAlcool / precoGasolina >=0.7 -> utilizar gasolina
           senão -> utilizar alcool
         */
        textDescricao.setText(String.format("RESULTADO = %.4f",resultado) + "\n-ÁLCOOL: R$ "+ editAlcool.getText() + "\n-GASOLINA: R$ " + editGasolina.getText());
        if (resultado >= 0.7) {
            textResultado.setText("ABASTEÇA COM GASOLINA");
        } else {
            textResultado.setText("ABASTEÇA COM ÁLCOOL");
        }
        editAlcool.setText("");
        editGasolina.setText("");
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.ajuda:
                startActivity(new Intent(this, Ajuda.class));
                break;
            case R.id.sobre:
                startActivity(new Intent(this,Sobre.class));
                break;
            case R.id.configuracao:
                startActivity(new Intent(this, Configuracao.class));
        }
        return super.onOptionsItemSelected(item);
    }

}