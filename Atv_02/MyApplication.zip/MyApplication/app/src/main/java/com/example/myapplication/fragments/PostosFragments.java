package com.example.myapplication.fragments;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.example.myapplication.R;
import com.example.myapplication.databinding.FragmentPostosFragmentsBinding;

public class PostosFragments extends Fragment {


    public PostosFragments(){

    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_postos_fragments, container, false);
        String[] nomePosto = {"SHELL","BR","IPIRANGA","ALE"};
        int[] imagem = {R.drawable.shell, R.drawable.br_logo, R.drawable.ipiranga_logo, R.drawable.ale_logo};
        GridView gridView = (GridView)view.findViewById(R.id.gridview);
        gridView.setAdapter(new GridAdapter(getContext(),nomePosto,imagem));
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(getActivity(), "Você selecionou " + nomePosto[i], Toast.LENGTH_SHORT).show();

            }
        });

        return view;
    }

    public class GridAdapter extends BaseAdapter{
        Context context;
        String[] nomePosto;
        int[] imagem;
        LayoutInflater layoutInflater;

        public GridAdapter(Context context, String[] nomePosto, int[] imagem) {
            this.context = context;
            this.nomePosto = nomePosto;
            this.imagem = imagem;
        }

        @Override
        public int getCount() {
            return nomePosto.length;
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            if(layoutInflater == null){
                layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            }
            if (view == null){
                view = layoutInflater.inflate(R.layout.grid_item, null);
            }
            ImageView imageView = view.findViewById(R.id.grid_image);
            TextView textView = view.findViewById(R.id.item_name);
            imageView.setImageResource(imagem[i]);
            textView.setText(nomePosto[i]);
            return view;
        }
    }
}