package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class Configuracao extends AppCompatActivity implements PopupMenu.OnMenuItemClickListener {

    ToggleButton toggleButton;
    ImageView imageView;
    Button longclick;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_configuracao);

        toggleButton = findViewById(R.id.toggle);
        imageView = findViewById(R.id.imageView);
        longclick = (Button)findViewById(R.id.btn_long_click);

        longclick.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
               TextView txt = (TextView) findViewById(R.id.txt);
               txt.setText("Hello, World!");
                return false;
            }
        });

        AutoCompleteTextView textView = (AutoCompleteTextView) findViewById(R.id.ac_text_view);
        String[] countries = getResources().getStringArray(R.array.countries_array);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, countries);
        textView.setAdapter(adapter);

        imageView.setImageDrawable(getResources().getDrawable(R.drawable.apagada));
        toggleButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (toggleButton.isChecked()) {
                    imageView.setImageDrawable(getResources().getDrawable(R.drawable.acesa));
                } else {
                    imageView.setImageDrawable(getResources().getDrawable(R.drawable.apagada));
                }
            }
        });
    }
    public void  showPopup(View v){
        PopupMenu popupMenu = new PopupMenu(this,v);
        popupMenu.setOnMenuItemClickListener(this);
        popupMenu.inflate(R.menu.popup_menu);
        popupMenu.show();
    }
    @Override
    public  boolean onMenuItemClick(MenuItem item){
        switch (item.getItemId()){
            case R.id.item1:
                Toast.makeText(this, "Item 1 clicked",Toast.LENGTH_SHORT).show();
                return true;
            case R.id.item2:
                Toast.makeText(this, "Item 2 clicked",Toast.LENGTH_SHORT).show();
                return true;
            case R.id.item3:
                Toast.makeText(this, "Item 3 clicked",Toast.LENGTH_SHORT).show();
                return true;
            default:
                return false;
        }
    }
}
