package br.ufc.quixada.scap.Model;

public class Pets {


}
